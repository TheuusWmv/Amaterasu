import os
from pathlib import Path
from ocr.image_processor import ImageProcessor
from organizers.identity_organizer import IdentityOrganizer
from organizers.energy_organizer import EnergyOrganizer
from utils.file_io import save_data, save_raw_text  # Importação corrigida

def selecionar_arquivo(lista_arquivos, tipo_documento):
    """Exibe menu interativo para seleção de arquivos"""
    print(f"\n╔{'═'*50}╗")
    print(f"║ {'Selecionar ' + tipo_documento.upper() + '':^48} ║")
    print(f"╠{'═'*50}╣")
    
    for i, arquivo in enumerate(lista_arquivos, 1):
        print(f"║ {i:2}. {arquivo.name[:45]:45} ║")
    
    print(f"╚{'═'*50}╝")
    
    while True:
        try:
            escolha = int(input(f"\nDigite o número do {tipo_documento} (1-{len(lista_arquivos)}): "))
            if 1 <= escolha <= len(lista_arquivos):
                return lista_arquivos[escolha-1]
            print("Erro: Número inválido!")
        except ValueError:
            print("Erro: Digite apenas números!")

def processar_documento(arquivo, organizer_class):
    processor = ImageProcessor()
    try:
        extracted_text = processor.extract_text(str(arquivo))
        
        # Salvar texto bruto do OCR
        log_filename = f"OCR_Log_{arquivo.stem}.txt"
        save_raw_text(extracted_text, filename=log_filename)
        
        organizer = organizer_class(extracted_text)
        data = organizer.organize()
        
        # Garantir que os dados retornados sejam um dicionário
        if isinstance(data, str):
            data = {"Extração": data}
        
        data['Arquivo_Origem'] = arquivo.name  # Adiciona o nome do arquivo
        return data
    except Exception as e:
        print(f"\n⚠️ Erro ao processar {arquivo.name}: {str(e)}")
        return None

def main():
    # Configuração inicial
    input_folder = 'images'
    image_extensions = ['.jpg', '.jpeg', '.png']
    
    # Carregar arquivos
    arquivos = list(Path(input_folder).iterdir())
    identidades = [f for f in arquivos if 'identidad' in f.name.lower() and f.suffix.lower() in image_extensions]
    talao = [f for f in arquivos if any(kw in f.name.lower() for kw in ['talão', 'talao']) and f.suffix.lower() in image_extensions]

    # Processar identidades
    if identidades:
        arquivo_sel = selecionar_arquivo(identidades, 'IDENTIDADE')
        dados_id = processar_documento(arquivo_sel, IdentityOrganizer)
        if dados_id:
            save_data(dados_id, output_folder='resultados', filename=f'{arquivo_sel.stem}.txt')
    
    # Processar talões
    if talao:
        arquivo_sel = selecionar_arquivo(talao, 'TALÃO DE ENERGIA')
        dados_energia = processar_documento(arquivo_sel, EnergyOrganizer)
        if dados_energia:
            save_data(dados_energia, output_folder='resultados', filename=f'{arquivo_sel.stem}.txt')

    print("\nProcessamento concluído! Verifique a pasta 'resultados'.")

if __name__ == '__main__':
    main()
