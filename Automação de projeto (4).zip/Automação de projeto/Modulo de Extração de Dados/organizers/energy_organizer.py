import ollama

class EnergyOrganizer:
    def __init__(self, text):
        self.text = text
        self.extracted_data = self._extract_data_from_ai()
    
    def _extract_data_from_ai(self):
        prompt = (
            "Extraia as seguintes informações do texto abaixo: "
            "Grupo e Subgrupo de Tensão, Tensão Nominal, Classificação, "
            "Endereço Completo (logradouro, quadra, lote, número, setor, CEP, cidade e estado) "
            "e Unidade Consumidora. "
            "Responda apenas com os valores correspondentes, sem repetir os rótulos. "
            "Se algum dado não for encontrado, simplesmente não o inclua na resposta.\n\n"
            f"Texto:\n{self.text}"
        )
        
        response = ollama.chat(model='gemma2:2b', messages=[{"role": "user", "content": prompt}])
        return response['message']['content'] if 'message' in response else ""
    
    def save_extracted_data(self, file_path):
        with open(file_path, 'w', encoding='utf-8') as file:
            file.write(self.extracted_data)
    
    def organize(self):
        return self.extracted_data