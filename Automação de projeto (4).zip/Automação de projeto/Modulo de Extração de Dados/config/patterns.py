IDENTITY_PATTERNS = {
    'CPF': r'\b\d{3}\.?\d{3}\.?\d{3}-?\d{2}\b',
    'RG': r'\b(?:Registro Geral|RG|Regist[Rr]o)\s*(\d{7,12})\b',
    'Nome': r'\b(?:Nome|Nome Completo|Titular|NoVe)\s*[:\-]?\s*([A-ZÀ-Ÿ][a-zà-ÿ]+(?:\s[A-ZÀ-Ÿ][a-zà-ÿ]+)+)\b',
    'Data de Expedição': r'\b(?:Data de Expedição|Expedido em|Emissão)\s*[:\-]?\s*(\d{2}/\d{2}/\d{4})\b',
    'Data de Nascimento': r'\b(?:Data de Nascimento|Nascimento|Nasc\.)\s*[:\-]?\s*(\d{2}/\d{2}/\d{4})\b'
}

ENERGY_PATTERNS = {
    'Conta Contrato': r'\d{8,12}',
    'CEP': r'\d{5}-?\d{3}',
    'Estado': r'\b(AC|AL|AP|AM|BA|CE|DF|ES|GO|MA|MT|MS|MG|PA|PB|PR|PE|PI|RJ|RN|RS|RO|RR|SC|SP|SE|TO)\b'
}