import easyocr

class ImageProcessor:
    def __init__(self, languages=['pt', 'en']):
        self.reader = easyocr.Reader(languages)
    
    def extract_text(self, image_path):
        """Extrai texto de uma imagem usando EasyOCR"""
        text_list = self.reader.readtext(image_path, detail=0)
        return "\n".join(text_list)