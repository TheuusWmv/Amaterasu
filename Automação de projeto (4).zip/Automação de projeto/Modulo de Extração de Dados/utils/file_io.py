import os
from pathlib import Path

def save_data(data, output_folder='resultados', filename='resultado.txt'):
    Path(output_folder).mkdir(exist_ok=True)
    output_path = Path(output_folder) / filename
    
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(f"=== Resultados de {data.get('Arquivo_Origem', 'desconhecido')} ===\n")
        for key, value in data.items():
            if key != 'Arquivo_Origem' and value:
                f.write(f"{key}: {value}\n")
        f.write("\n")
    
    print(f"Dados salvos em {output_path}")

def save_raw_text(text, output_folder='ocr_logs', filename='OCR_log.txt'):
    """Salva o texto bruto do OCR em arquivo separado"""
    Path(output_folder).mkdir(exist_ok=True)
    output_path = Path(output_folder) / filename
    
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write("=== TEXTO BRUTO EXTRAÍDO DO OCR ===\n")
        f.write(text)
    
    print(f"Log OCR salvo em: {output_path}")