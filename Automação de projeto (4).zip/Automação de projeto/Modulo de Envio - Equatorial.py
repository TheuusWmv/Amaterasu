from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
import os
import time
import re


def processar_arquivo_info(caminho_arquivo):
    """Processa o arquivo de informações e extrai os dados necessários para o formulário."""
    dados = {}
    
    with open(caminho_arquivo, 'r', encoding='utf-8') as arquivo:
        conteudo = arquivo.read()
        
        # Mapeamento de padrões para extração de dados usando expressões regulares
        padroes = {
            'solicitante_nome': r'Solicitante\s*-\s*Nome completo\s*:\s*(.+?)[\r\n]',
            'solicitante_rg': r'RG\s*:\s*(.+?)[\r\n]',
            'solicitante_cpf': r'cpf\s*:\s*(.+?)[\r\n]',
            'solicitante_celular': r'Celular\s*:\s*(.+?)[\r\n]',
            'resp_nome': r'Responsável técnico\s*-\s*Nome completo\s*:\s*(.+?)[\r\n]',
            'resp_rg': r'Responsável técnico[\s\S]*?RG\s*:\s*(.+?)[\r\n]',
            'resp_cpf': r'Responsável técnico[\s\S]*?cpf\s*:\s*(.+?)[\r\n]',
            'resp_email': r'email\s*:\s*(.+?)[\r\n]',
            'resp_celular': r'Responsável técnico[\s\S]*?Celular\s*:\s*(.+?)[\r\n]'
        }
        
        # Extrair dados usando o mapeamento de padrões
        for chave, padrao in padroes.items():
            match = re.search(padrao, conteudo)
            if match:
                dados[chave] = match.group(1).strip()
        
        # Extrair dados da geração com mais detalhes
        geracao_match = re.search(r'Dados da Geração\s*:\s*(.+?)(?:$|[\r\n])', conteudo)
        if geracao_match:
            geracao_texto = geracao_match.group(1).strip()
            dados['dados_geracao'] = geracao_texto
            
            # Tentar extrair especificamente o valor do disjuntor
            disjuntor_match = re.search(r'disjuntor\s+de\s+proteção\s+(\d+)A', geracao_texto, re.IGNORECASE) or \
                              re.search(r'(\d+)A', geracao_texto)
            if disjuntor_match:
                dados['disjuntor'] = disjuntor_match.group(1)
    
    return dados


def encontrar_arquivos(diretorio, nome_pessoa):
    """Localiza os arquivos necessários para upload na pasta especificada com base no nome da pessoa."""
    arquivos = {}
    
    # Padrões para cada tipo de documento que precisamos encontrar
    padroes = {
        'memorial': [f"Memorial Descritivo - {nome_pessoa}.pdf", f"memorial-{nome_pessoa}.pdf", "memorial", "Memorial"],
        'solicitacao': [f"Solicitação de Acesso - {nome_pessoa}.pdf", f"solicitacao-{nome_pessoa}.pdf", "solicitacao", "Solicitação"],
        'art': [f"ART-{nome_pessoa}.pdf", f"art-{nome_pessoa}.pdf", "art", "ART"],
        'diagrama': [f"Diagrama Unifilar-{nome_pessoa}.pdf", f"Diagrama-{nome_pessoa}.pdf", f"diagrama-{nome_pessoa}.pdf", "diagrama", "Diagrama"],
        'inmetro': ["inmetro", f"inmetro-{nome_pessoa}.pdf", "certificado", "Certificado"],
        'rateio': [f"rateio - {nome_pessoa}.pdf", f"rateio-{nome_pessoa}.pdf", "rateio", "Rateio"],
        'juridico': [f"juridico-{nome_pessoa}.pdf", f"juridico - {nome_pessoa}.pdf", "juridico", "Juridico"],
        'aneel': [f"aneel-{nome_pessoa}.pdf", f"aneel - {nome_pessoa}.pdf", "aneel", "Aneel"]
    }
    
    # Verificar cada arquivo no diretório e associar ao tipo correto
    for arquivo in os.listdir(diretorio):
        arquivo_lower = arquivo.lower()
        for tipo, padroes_list in padroes.items():
            for padrao in padroes_list:
                if padrao.lower() in arquivo_lower:
                    arquivos[tipo] = os.path.join(diretorio, arquivo)
                    break
    
    # Verificar se os arquivos obrigatórios foram encontrados
    arquivos_obrigatorios = ['memorial', 'solicitacao', 'art', 'diagrama', 'inmetro']
    for arq in arquivos_obrigatorios:
        if arq not in arquivos:
            print(f"AVISO: Arquivo obrigatório '{arq}' não foi encontrado!")
    
    return arquivos


def enviar_documentos(diretorio):
    """Função principal para automatizar o envio de documentos ao portal da Equatorial."""
    # Configuração do Chrome Driver com opções para evitar detecção de automação
    chrome_options = Options()
    chrome_options.add_argument("--start-maximized")  # Iniciar maximizado
    chrome_options.add_argument("--disable-notifications")  # Desabilitar notificações
    chrome_options.add_argument("--disable-blink-features=AutomationControlled")  # Evitar detecção
    chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
    chrome_options.add_experimental_option('useAutomationExtension', False)
    
    # Inicializar o driver com wait explícito para aguardar elementos
    servico = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=servico, options=chrome_options)
    wait = WebDriverWait(driver, 30)  # Tempo máximo de espera: 30 segundos
    
    try:
        # Processar arquivo de informações primeiro
        arquivos_info = [f for f in os.listdir(diretorio) if f.startswith("info_")]
        if not arquivos_info:
            raise Exception("Arquivo de informações não encontrado. Verifique se existe um arquivo começando com 'info_'")
            
        caminho_info = os.path.join(diretorio, arquivos_info[0])
        dados = processar_arquivo_info(caminho_info)
        print("\n" + "="*80)
        print("✅ Dados processados com sucesso")
        print("="*80 + "\n")

        # Acesso ao site oficial da Equatorial
        driver.get("https://ma.equatorialenergia.com.br/sua-conta/mini-e-micro-geracao/parecer-de-acesso/#micro-10")
        print("\n" + "-"*80)
        print("🌐 Acessando site oficial da Equatorial Energia...")
        print("-"*80 + "\n")
        
        # Função auxiliar para clicar em elementos com retry para maior robustez
        def clicar_elemento_com_retry(locator_list, nome_elemento, max_retries=3):
            """Tenta clicar em um elemento com várias tentativas e diferentes localizadores."""
            for tentativa in range(max_retries):
                for locator in locator_list:
                    try:
                        elemento = wait.until(EC.element_to_be_clickable(locator))
                        driver.execute_script("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", elemento)
                        time.sleep(1)
                        elemento.click()
                        print(f"  ✓ Clicou em '{nome_elemento}'")
                        return True
                    except Exception as e:
                        print(f"  ⚠️ Tentativa {tentativa + 1} falhou para '{nome_elemento}': {str(e)[:50]}...")
                time.sleep(2)
            return False

        # Lidar com o banner de cookies que pode aparecer
        clicar_elemento_com_retry(
            [(By.XPATH, "//button[contains(text(), 'Continuar no site')]")],
            "Continuar no site"
        )

        # Clicar no botão "Sim" para iniciar o processo
        clicar_elemento_com_retry(
            [(By.XPATH, "//a[contains(@class, 'wp-block-button__link') and contains(text(), 'Sim')]"),
             (By.XPATH, "//a[@href='#form-parecer-acesso']")],
            "Sim"
        )

        # Clicar em "Microgeração distribuída até 10kW"
        clicar_elemento_com_retry(
            [(By.XPATH, "//a[contains(@href, '#micro-10')]"),
             (By.XPATH, "//a[contains(text(), 'Microgeração distribuída até 10kW')]")],
            "Microgeração até 10kW"
        )

        # Após clicar em "Microgeração até 10kW", aguardar carregamento completo
        time.sleep(3)  # Tempo extra para o formulário carregar completamente
        # Aguardar o formulário micro-10 ficar visível
        wait.until(EC.presence_of_element_located((By.ID, "micro-10")))
        print("Formulário 'Microgeração até 10kW' encontrado")
        
        # Mapeamento dos campos do formulário com os dados extraídos
        campos_mapeados = {
            'nome_completo': dados.get('solicitante_nome'),
            'rg': dados.get('solicitante_rg'),
            'cpf': dados.get('solicitante_cpf'),
            'celular': dados.get('solicitante_celular'),
            'responsavel_tecnico_nome_completo': dados.get('resp_nome'),
            'responsavel_tecnico_rg': dados.get('resp_rg'),
            'responsavel_tecnico_cpf': dados.get('resp_cpf'),
            'responsavel_tecnico_email': dados.get('resp_email'),
            'responsavel_tecnico_celular': dados.get('resp_celular'),
            'dados_tecnicos_disjuntor': dados.get('disjuntor')
        }
        
        # Garantir que estamos trabalhando com o formulário micro-10
        formulario = wait.until(EC.presence_of_element_located((By.ID, "micro-10")))
        
        # Preencher cada campo do formulário
        print("\n" + "-"*80)
        print("📝 PREENCHENDO CAMPOS DO FORMULÁRIO")
        print("-"*80)
        for campo, valor in campos_mapeados.items():
            if valor:
                try:
                    # Tentar encontrar o campo dentro do formulário específico
                    campo_input = formulario.find_element(By.NAME, campo)
                    driver.execute_script("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", campo_input)
                    time.sleep(0.5)
                    
                    # Limpar e preencher o campo
                    campo_input.clear()
                    # Remover caracteres não numéricos para campos específicos
                    if campo in ['rg', 'cpf', 'dados_tecnicos_disjuntor']:
                        valor = re.sub(r'[^\d]', '', valor)
                    campo_input.send_keys(valor)
                    print(f"  ✓ Campo '{campo}' preenchido com '{valor}'")
                except Exception as e:
                    print(f"  ❌ Erro ao preencher '{campo}': {str(e)[:50]}...")
                time.sleep(0.5)
        print("-"*80 + "\n")

        # Anexar documentos necessários
        nome_pessoa = arquivos_info[0].replace("info_", "").replace(".txt", "")
        documentos = encontrar_arquivos(diretorio, nome_pessoa)
        
        # Garantir que estamos no formulário correto
        formulario = wait.until(EC.presence_of_element_located((By.ID, "micro-10")))
        
        # Mapeamento dos IDs e nomes dos campos de arquivo
        campos_arquivo = {
            'solicitacao': {'id': 'solicitacao-acesso', 'name': 'hidden_solicitacao-acesso'},
            'memorial': {'id': 'memorial-descritivo', 'name': 'hidden_memorial-descritivo'},
            'art': {'id': 'art-responsavel', 'name': 'hidden_art-responsavel'},
            'diagrama': {'id': 'diagrama-unifiliar', 'name': 'hidden_diagrama-unifiliar'},
            'inmetro': {'id': 'certificados-conformidade', 'name': 'hidden_certificados-conformidade'},
            'rateio': {'id': 'lista-contas-contrato', 'name': 'hidden_lista-contas-contrato'},
            'juridico': {'id': 'instrumento-juridico', 'name': 'hidden_instrumento-juridico'},
            'aneel': {'id': 'documento-aneel', 'name': 'hidden_documento-aneel'}
        }

        # Contador para verificar se todos os arquivos foram anexados corretamente
        arquivos_anexados = 0
        total_arquivos = len([tipo for tipo in documentos if tipo in campos_arquivo])
        
        # Anexar cada documento encontrado
        print("\n" + "-"*80)
        print("📎 ANEXANDO DOCUMENTOS")
        print("-"*80)
        for tipo, info in campos_arquivo.items():
            if tipo in documentos:
                try:
                    # Encontrar o elemento de input dentro do formulário correto
                    input_element = formulario.find_element(By.NAME, info['name'])
                    
                    # Tornar o elemento interativo (muitos campos de arquivo são ocultos por padrão)
                    driver.execute_script("""
                        arguments[0].style.display = 'block';
                        arguments[0].style.opacity = '1';
                        arguments[0].style.visibility = 'visible';
                        arguments[0].style.height = 'auto';
                        arguments[0].style.position = 'static';
                    """, input_element)
                    
                    # Rolar até o elemento
                    driver.execute_script("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", input_element)
                    time.sleep(1)
                    
                    # Enviar o arquivo
                    caminho_absoluto = os.path.abspath(documentos[tipo])
                    input_element.send_keys(caminho_absoluto)
                    print(f"  📄 Anexando '{tipo}': {os.path.basename(caminho_absoluto)}")
                    
                    # Aguardar confirmação do upload (preview da imagem)
                    preview_id = f"preview-image-{info['id']}"
                    try:
                        preview = WebDriverWait(driver, 5).until(
                            EC.presence_of_element_located((By.ID, preview_id))
                        )
                        print(f"  ✅ Documento '{tipo}' anexado com sucesso!")
                        arquivos_anexados += 1
                    except:
                        print(f"  ⚠️ Aviso: Preview não encontrado para '{tipo}', verifique manualmente")
                    
                    time.sleep(1)
                    
                except Exception as e:
                    print(f"  ❌ Erro ao anexar '{tipo}': {str(e)[:50]}...")
        
        print(f"\n  📊 Resumo: Anexados {arquivos_anexados} de {total_arquivos} arquivos")
        print("-"*80 + "\n")
        
        # Aguardar um momento após anexar todos os arquivos
        time.sleep(5)  # Tempo aumentado para garantir que todos os uploads sejam concluídos
        
        # Preencher emails de confirmação somente após anexar todos os arquivos
        if 'resp_email' in dados:
            print("\n" + "-"*80)
            print("📧 PREENCHENDO CAMPOS DE EMAIL")
            print("-"*80)
            print(f"  📧 Email a ser utilizado: {dados['resp_email']}")
            
            # Verificar se o email está definido corretamente
            email_valor = dados['resp_email']
            if not email_valor or email_valor.strip() == "":
                email_valor = "exemplo@email.com"  # Valor padrão caso esteja vazio
                print(f"  ⚠️ Email vazio! Usando valor padrão: {email_valor}")
            
            # Função para preencher emails com JavaScript (mais confiável para campos dinâmicos)
            def preencher_emails_js():
                return driver.execute_script("""
                    var emailValue = arguments[0];
                    console.log("Email recebido pelo JavaScript: " + emailValue);
                    
                    // Obter todos os campos de email na página
                    let camposEmail = document.querySelectorAll('input[type="email"]');
                    let botaoCheck = document.querySelector('input[data-role="check-email"]');
                    
                    if (camposEmail.length >= 2 && botaoCheck) {
                        // Preencher os campos de email
                        camposEmail.forEach(campo => {
                            campo.value = emailValue;
                            // Disparar eventos para validação do formulário
                            campo.dispatchEvent(new Event('input', { bubbles: true }));
                            campo.dispatchEvent(new Event('change', { bubbles: true }));
                            console.log("Campo email preenchido: " + campo.name + " com valor: " + campo.value);
                        });
                        
                        // Clicar no botão de verificação
                        botaoCheck.click();
                        console.log("Botão de verificação clicado");
                        return true;
                    }
                    return false;
                """, email_valor)
            
            # Tentar preencher emails com sistema de retry para maior confiabilidade
            max_tentativas = 3
            for tentativa in range(max_tentativas):
                try:
                    # Esperar que o formulário esteja completamente carregado
                    time.sleep(2)
                    print(f"\n  🔄 Tentativa {tentativa + 1} de {max_tentativas} para preencher emails...")
                    
                    if preencher_emails_js():
                        print(f"  ✅ Emails preenchidos com sucesso via JavaScript!")
                        time.sleep(2)
                        break
                    else:
                        print(f"  ⚠️ Campos de email não encontrados via JavaScript")
                        
                        # Tentar abordagem alternativa com Selenium direto
                        print(f"  🔄 Tentando abordagem alternativa com Selenium...")
                        campos_email = driver.find_elements(By.XPATH, "//input[@type='email']")
                        if campos_email and len(campos_email) >= 2:
                            for campo in campos_email:
                                campo.clear()
                                campo.send_keys(email_valor)
                                print(f"  ✓ Campo '{campo.get_attribute('name')}' preenchido via Selenium")
                            
                            # Tentar clicar no botão de verificação
                            botoes_verificacao = driver.find_elements(By.XPATH, "//input[@data-role='check-email']")
                            if botoes_verificacao:
                                botoes_verificacao[0].click()
                                print("  ✓ Botão de verificação clicado via Selenium")
                                time.sleep(2)
                                break
                
                except Exception as e:
                    print(f"  ❌ Erro na tentativa {tentativa + 1}: {str(e)[:50]}...")

        # Aguardar confirmação do usuário antes de enviar o formulário
        input("Pressione Enter para enviar o formulário...")
        
        # Clicar no botão de enviar
        botao_enviar = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, "button[type='submit']")))
        botao_enviar.click()
        print("Formulário enviado com sucesso!")

    except Exception as e:
        print(f"Erro durante a execução: {e}")
    finally:
        # Aguardar antes de fechar o navegador
        time.sleep(5)
        driver.quit()

# Ponto de entrada do programa
if __name__ == "__main__":
    try:
        # Obter o diretório atual onde o script está localizado
        diretorio_atual = os.path.dirname(os.path.abspath(__file__))
        print(f"Iniciando automação no diretório: {diretorio_atual}")
        
        # Executar função principal
        enviar_documentos(diretorio_atual)
        
    except Exception as e:
        print(f"Erro ao iniciar o programa: {e}")
        input("Pressione Enter para sair...")